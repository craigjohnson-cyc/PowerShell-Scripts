﻿$ServerInstance = "tbddb1x"
$Database = "MID"
$query = "SELECT [EMPLID],[COMPANY],[AL_EMPL_STATUS],[FIRST_NAME],[MIDDLE_NAME],[LAST_NAME],[EMAIL_ADDRESS],[SSN],[REHIRE_DT],[HIRE_DT],[TERMINATION_DT],[FULL_PART_TIME],[JOBCODE]"
$query = $querry + ",[FLSA_STATUS],[EMPL_TYPE],[STD_HOURS],[JOBTITLE],[FLSA_STATUS_DS] FROM [MID].[ADP].[Employee_Demographics]"

Invoke-SqlCmd -Query $query -ServerInstance "$ServerInstance" -Database "$Database" 